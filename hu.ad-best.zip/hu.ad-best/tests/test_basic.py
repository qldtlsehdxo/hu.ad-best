"""Tests that run without network access or an API key.

We test the parts we own — prompt construction, file/literal input handling,
and CLI argument parsing — and leave the live API call out of CI.
"""

import sys
from pathlib import Path

import pytest

sys.path.insert(0, str(Path(__file__).resolve().parents[1] / "src"))

from hu_ad_best import prompts
from hu_ad_best.cli import _read
from hu_ad_best.engine import Result


def test_decompose_prompt_includes_inputs():
    user = prompts.DECOMPOSE_USER_TEMPLATE.format(
        reference="a moody noir spot", target="a 15s reel"
    )
    assert "a moody noir spot" in user
    assert "a 15s reel" in user
    assert "Deployable Element List" in user


def test_trend_prompt_includes_input():
    user = prompts.TREND_USER_TEMPLATE.format(trend="jump-cut vlogs")
    assert "jump-cut vlogs" in user
    assert "Transferable Principle" in user


def test_read_literal_text():
    assert _read("just some text") == "just some text"


def test_read_file(tmp_path):
    f = tmp_path / "ref.txt"
    f.write_text("from a file", encoding="utf-8")
    assert _read(str(f)) == "from a file"


def test_result_markdown():
    r = Result(title="T", content="body")
    assert r.to_markdown() == "# T\n\nbody\n"


def test_missing_api_key_raises(monkeypatch):
    monkeypatch.delenv("OPENAI_API_KEY", raising=False)
    from hu_ad_best import engine

    with pytest.raises(RuntimeError):
        engine.decompose_reference("ref", "target")
