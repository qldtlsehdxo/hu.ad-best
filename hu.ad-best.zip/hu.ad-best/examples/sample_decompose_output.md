# Reference Decomposition

> Example output produced by `hu-ad-best decompose`. Illustrative — your real
> runs will be tailored to your reference and target.

## Shot & Composition
- Reference: single unbroken handheld follow-shot, subject kept off-center.
  -> Affordable path: one gimbal pass on a phone, subject framed left-third;
  rehearse the walk twice so you only need 2–3 takes.

## Color / Grade Direction
- Reference: warm, slightly overexposed golden-hour grade.
  -> Affordable path: shoot 1 hour before sunset; lift exposure +0.3 in-app,
  push warmth, crush nothing in the shadows. No paid LUT needed.

## Pacing & Editing Rhythm
- Reference: slow build, single take, payoff in last 3s.
  -> Affordable path: hold the single take; add one hard cut to the product at 17s.

## Lighting
- Reference: natural backlight, lens flare.
  -> Affordable path: sun behind subject, white foam board as fill on the shadow side.

## Sound & Music
- Reference: diegetic only, one piano note at the end.
  -> Affordable path: record real ambient on-site; royalty-free single piano sting for the button.

## Budget-Conscious Substitutions
- Steadicam -> phone gimbal. Color house -> in-app grade. Composer -> one licensed sting.

## Deployable Element List
- [ ] Golden-hour shoot window booked
- [ ] Gimbal walk rehearsed (2–3 takes)
- [ ] Foam-board fill on set
- [ ] Ambient audio recorded clean
- [ ] Product hard-cut at ~17s
- [ ] Single piano sting on the button
