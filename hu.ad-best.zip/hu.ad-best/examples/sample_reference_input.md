# Sample Reference Input

A 30-second perfume commercial: single continuous handheld shot following a
person walking through a sunlit market at golden hour. Warm, slightly
overexposed grade. Diegetic sound only (footsteps, ambient market noise) until
the final 3 seconds, where a single piano note drops in. No dialogue. Product
appears only in the last frame.

## Target piece the creator wants to make
A 20-second Instagram Reel for a small local coffee roaster, shot on a phone +
one gimbal, budget under 200,000 KRW, one shoot day.
