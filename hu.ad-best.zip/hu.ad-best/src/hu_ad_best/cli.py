"""Command-line interface for hu.ad-best.

Usage:
    hu-ad-best decompose --reference ref.txt --target "my 30s product spot"
    hu-ad-best trend --input "jump-cut day-in-the-life vlogs"
"""

from __future__ import annotations

import argparse
import sys
from pathlib import Path

from . import __version__, engine


def _read(value: str) -> str:
    """If value is an existing file path, read it; otherwise treat as literal text."""
    p = Path(value)
    if p.exists() and p.is_file():
        return p.read_text(encoding="utf-8")
    return value


def _output(text: str, out: str | None) -> None:
    if out:
        Path(out).write_text(text, encoding="utf-8")
        print(f"Saved to {out}")
    else:
        print(text)


def main(argv: list[str] | None = None) -> int:
    parser = argparse.ArgumentParser(
        prog="hu-ad-best",
        description="AI tools for advertising and film production.",
    )
    parser.add_argument("--version", action="version", version=f"hu-ad-best {__version__}")
    parser.add_argument("--model", default="gpt-4o-mini", help="OpenAI model to use")
    sub = parser.add_subparsers(dest="command", required=True)

    d = sub.add_parser("decompose", help="Break a reference into editable production elements")
    d.add_argument("--reference", required=True, help="Reference text or path to a file")
    d.add_argument("--target", required=True, help="What you want to make")
    d.add_argument("--out", help="Optional output file path")

    t = sub.add_parser("trend", help="Analyze why a trend appeals to MZ audiences")
    t.add_argument("--input", required=True, help="Trend description, format, or path to a file")
    t.add_argument("--out", help="Optional output file path")

    args = parser.parse_args(argv)

    try:
        if args.command == "decompose":
            result = engine.decompose_reference(
                reference=_read(args.reference),
                target=args.target,
                model=args.model,
            )
        elif args.command == "trend":
            result = engine.analyze_trend(trend=_read(args.input), model=args.model)
        else:  # pragma: no cover
            parser.error("unknown command")
    except RuntimeError as exc:
        print(f"Error: {exc}", file=sys.stderr)
        return 1

    _output(result.to_markdown(), args.out)
    return 0


if __name__ == "__main__":  # pragma: no cover
    raise SystemExit(main())
