"""hu.ad-best — AI tools for advertising and film production."""

__version__ = "0.1.0"
