"""Core engine for hu.ad-best.

Wraps the OpenAI Chat Completions API for the two tools. Designed so the
prompt harnesses in prompts.py do the heavy lifting and this module stays
small and testable.
"""

from __future__ import annotations

import os
from dataclasses import dataclass

from . import prompts


@dataclass
class Result:
    """A single analysis result."""

    title: str
    content: str

    def to_markdown(self) -> str:
        return f"# {self.title}\n\n{self.content}\n"


def _client():
    """Lazily build an OpenAI client so the package imports without the key."""
    try:
        from openai import OpenAI
    except ImportError as exc:  # pragma: no cover
        raise RuntimeError(
            "The 'openai' package is required. Install with: pip install openai"
        ) from exc

    api_key = os.environ.get("OPENAI_API_KEY")
    if not api_key:
        raise RuntimeError(
            "OPENAI_API_KEY is not set. Copy .env.example to .env and add your key."
        )
    return OpenAI(api_key=api_key)


def _complete(system: str, user: str, model: str) -> str:
    client = _client()
    response = client.chat.completions.create(
        model=model,
        messages=[
            {"role": "system", "content": system},
            {"role": "user", "content": user},
        ],
    )
    return response.choices[0].message.content or ""


def decompose_reference(reference: str, target: str, model: str = "gpt-4o-mini") -> Result:
    """Feature 1: break a reference into editable production elements."""
    user = prompts.DECOMPOSE_USER_TEMPLATE.format(reference=reference, target=target)
    content = _complete(prompts.DECOMPOSE_SYSTEM, user, model)
    return Result(title="Reference Decomposition", content=content)


def analyze_trend(trend: str, model: str = "gpt-4o-mini") -> Result:
    """Feature 2: explain why a trend appeals across cultural/national/artistic lenses."""
    user = prompts.TREND_USER_TEMPLATE.format(trend=trend)
    content = _complete(prompts.TREND_SYSTEM, user, model)
    return Result(title="Trend Appeal Analysis", content=content)
