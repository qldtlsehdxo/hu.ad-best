# Contributing to hu.ad-best

Thanks for your interest. This project collects field-tested AI workflows for
advertising and film production, and contributions from other creators are
welcome.

## Ways to contribute

- **New reference breakdowns** — add anonymized examples under `examples/`.
- **Prompt harness improvements** — refine the prompts in
  `src/hu_ad_best/prompts.py` so outputs are more actionable for small crews.
- **New analysis lenses** — propose additional cultural/artistic angles for the
  trend analyzer.
- **Docs & templates** — help non-developer creators get started faster.

## Development setup

```bash
git clone https://github.com/<your-username>/hu.ad-best.git
cd hu.ad-best
python -m venv .venv && source .venv/bin/activate
pip install -e ".[dev]"
cp .env.example .env   # then add your OPENAI_API_KEY
pytest
```

## Pull requests

1. Open an issue describing the change first for anything non-trivial.
2. Keep PRs focused and include a short rationale.
3. Run `pytest` before submitting.

## Code of conduct

Be constructive and respectful. This is a learning-oriented project for
creators, many of whom are not professional developers.
