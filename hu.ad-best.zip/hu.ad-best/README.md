# hu.ad-best

> Research on AI tools for advertising and film production.
> AI-assisted workflows that help small, budget-constrained creators turn visual references into actionable production plans — and understand *why* a trend works.

---

## English

### Overview

**hu.ad-best** is an open-source research project that documents and builds AI tools for advertising and film production. It is maintained by a working advertising creative who aims toward filmmaking, and it focuses on a single hard problem: **delivering high-quality video on a limited budget.**

The project provides two core AI-assisted tools.

### Core Features

**1. Reference Decomposition Engine**
Analyzes a target video reference and breaks it down into editable, deployable production elements — shot composition, color/grade direction, pacing, lighting, sound, and editing rhythm. Instead of leaving "I want it to feel like *this*" as a vague brief, it produces a structured, modifiable checklist of components that a creator can adapt to the video they actually want to make.

- Input: a reference video / link / description of a target look
- Output: a structured, editable breakdown of production elements
- Use: turn intuition into a concrete pre-production plan a small crew can execute

**2. Trend Appeal Analysis**
Analyzes current video trends and explains *why* they intuitively appeal to MZ-generation audiences — across cultural, national, and artistic dimensions. Rather than only describing *what* is trending, it articulates the underlying drivers of appeal so creators can apply the principle, not just copy the surface.

- Input: a trend, format, or reference clip
- Output: a cultural / national / artistic read on why it resonates
- Use: ground creative decisions in *why it works*, not guesswork

### How to Use

```bash
git clone https://github.com/<your-username>/hu.ad-best.git
cd hu.ad-best
pip install -e .
cp .env.example .env   # then add your OPENAI_API_KEY

# Feature 1 — decompose a reference into editable production elements
hu-ad-best decompose --reference examples/sample_reference_input.md \
                     --target "a 20s reel for a local coffee roaster" \
                     --out breakdown.md

# Feature 2 — analyze why a trend appeals to MZ audiences
hu-ad-best trend --input "jump-cut day-in-the-life vlogs" --out trend.md
```

> See `examples/` for sample inputs and outputs.

### Roadmap

- [ ] Treatment & storyboard draft generation
- [ ] Shooting schedule & budget simulation
- [ ] Usage guides and templates for non-technical creators

### License

MIT License

---

## 한글

### 소개

**hu.ad-best**는 광고·영화 제작을 위한 AI 도구를 연구하고 만드는 오픈소스 프로젝트입니다. 광고 현장에서 일하며 영화 제작을 지향하는 실무자가 운영하며, **"한정된 예산으로 높은 완성도의 영상을 만든다"**는 하나의 어려운 문제에 집중합니다.

이 프로젝트는 두 가지 핵심 AI 도구를 제공합니다.

### 주요 기능

**1. 레퍼런스 분해 엔진 (Reference Decomposition Engine)**
참고하려는 영상 레퍼런스를 분석해, 내가 만들고 싶은 영상물에 곧바로 배치할 수 있는 세부 제작 항목으로 분해합니다 — 화면 구성, 색감·그레이딩 방향, 호흡, 조명, 사운드, 편집 리듬 등. "이런 느낌으로 가고 싶다"는 막연한 브리프를, **정리하고 수정할 수 있는 구조화된 체크리스트**로 바꿔 줍니다.

- 입력: 레퍼런스 영상 / 링크 / 추구하는 룩에 대한 설명
- 출력: 수정 가능한 형태로 정리된 제작 세부 항목
- 활용: 직관을, 소규모 팀이 실행할 수 있는 구체적 프리프로덕션 플랜으로 전환

**2. 트렌드 매력 분석 (Trend Appeal Analysis)**
현재의 영상 트렌드를 분석해, 그것이 **왜 MZ 트렌드 세대에게 문화적·국가적·예술적으로 직관적인 매력을 갖는지**를 짚어냅니다. 무엇이 유행하는지만 설명하는 게 아니라, 그 매력의 근본 동인을 언어화하여 표면을 따라 하는 대신 원리를 적용할 수 있게 합니다.

- 입력: 트렌드 / 포맷 / 레퍼런스 클립
- 출력: 왜 통하는지에 대한 문화·국가·예술적 해석
- 활용: 감이 아니라 "왜 먹히는가"를 근거로 한 창작 의사결정

### 사용 방법

```bash
git clone https://github.com/<your-username>/hu.ad-best.git
cd hu.ad-best
pip install -e .
cp .env.example .env   # 이후 OPENAI_API_KEY 입력

# 기능 1 — 레퍼런스를 수정 가능한 제작 항목으로 분해
hu-ad-best decompose --reference examples/sample_reference_input.md \
                     --target "로컬 커피 로스터리용 20초 릴" \
                     --out breakdown.md

# 기능 2 — 트렌드가 MZ에게 왜 매력적인지 분석
hu-ad-best trend --input "점프컷 데이인더라이프 브이로그" --out trend.md
```

> 샘플 입력/출력은 `examples/` 디렉터리에 있습니다.

### 향후 계획

- [ ] 기획안·콘티 초안 자동 생성
- [ ] 촬영 일정·예산 시뮬레이션
- [ ] 비전공 창작자용 활용 가이드 및 템플릿

### 라이선스

MIT License
